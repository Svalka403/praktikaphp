<?php
$user = 'sw9t';
$base_name = 'sw9t';
$pass = '123321';
$host = 'localhost';
  $db = new PDO("mysql:host=$host;dbname=$base_name", $user, $pass);
 //$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $db->query('SELECT * FROM users');
foreach($stmt as $v) {
print_r($v);
}
?>